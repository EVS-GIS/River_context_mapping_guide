<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.16.0" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" minScale="1e+08" maxScale="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
  </flags>
  <pipe>
    <provider>
      <resampling maxOversampling="2" zoomedOutResamplingMethod="nearestNeighbour" zoomedInResamplingMethod="nearestNeighbour" enabled="false"/>
    </provider>
    <rasterrenderer type="singlebandpseudocolor" opacity="1" band="1" classificationMin="600" classificationMax="2000">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <rastershader>
        <colorrampshader colorRampType="INTERPOLATED" labelPrecision="0" classificationMode="1" clip="0">
          <colorramp type="gradient" name="[source]">
            <prop k="color1" v="252,165,10,255"/>
            <prop k="color2" v="0,0,140,255"/>
            <prop k="discrete" v="0"/>
            <prop k="stops" v="0.25:250,230,160,255;0.5:180,245,255,255;0.75:0,160,240,255"/>
          </colorramp>
          <item color="#fca50a" value="600" label="600 mm"/>
          <item color="#fae6a0" value="950" label="950 mm"/>
          <item color="#b4f5ff" value="1300" label="1300 mm"/>
          <item color="#00a0f0" value="1650" label="1650 mm"/>
          <item color="#00008c" value="2000" label="2000 mm"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
  </pipe>
  <blendMode>0</blendMode>
</qgis>		
