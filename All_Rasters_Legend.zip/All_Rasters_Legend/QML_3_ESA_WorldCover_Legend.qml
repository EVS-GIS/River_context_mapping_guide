<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.16.0" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" minScale="1e+08" maxScale="0">
  <pipe>
    <provider>
      <resampling maxOversampling="2" zoomedOutResamplingMethod="nearestNeighbour" zoomedInResamplingMethod="nearestNeighbour" enabled="false"/>
    </provider>
    <rasterrenderer type="paletted" opacity="1" band="1">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <colorPalette>
        <paletteEntry color="#006400" alpha="255" value="10" label="Forêts de feuillus"/>
        <paletteEntry color="#ffbb22" alpha="255" value="20" label="Cultures pluviales"/>
        <paletteEntry color="#ffff4c" alpha="255" value="30" label="Prairies/herbacées"/>
        <paletteEntry color="#f096ff" alpha="255" value="40" label="Mangroves"/>
        <paletteEntry color="#fa0000" alpha="255" value="50" label="Zones bâties"/>
        <paletteEntry color="#b4b4b4" alpha="255" value="60" label="Sols nus"/>
        <paletteEntry color="#f0f0f0" alpha="255" value="70" label="Neige/glace"/>
        <paletteEntry color="#0064c8" alpha="255" value="80" label="Eau"/>
        <paletteEntry color="#00a0f0" alpha="255" value="90" label="Zones humides"/>
        <paletteEntry color="#00cf75" alpha="255" value="95" label="Végétation aquatique"/>
        <paletteEntry color="#fae6a0" alpha="255" value="100" label="Autres"/>
      </colorPalette>
    </rasterrenderer>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
